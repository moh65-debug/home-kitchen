import os
import json
import time
import uuid
import requests
import shutil
import hashlib
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from PIL import Image
from io import BytesIO
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from datetime import datetime, timedelta
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
import sys
import io
import locale

if sys.stdout.encoding != 'UTF-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')

# === CONFIGURATION ===
DOWNLOAD_DIR = "amazon_products"
PROCESSED_ASINS_FILE = "processed_product_asins.txt"  # Tracks ASINs already processed
UPLOADED_IMAGE_PATHS_FILE = "uploaded_image_paths.txt"  # Tracks specific images already uploaded
SCHEDULED_TIMES_FILE = "scheduled_times.txt" # Tracks last scheduled date and count

MIN_WIDTH, MIN_HEIGHT = 150, 150
NUM_PRODUCTS = None  # Set to a number (e.g., 5) to limit the total products processed, or None for all found
PINTEREST_URL = "https://www.pinterest.com/" # Changed to base Pinterest URL
PINTEREST_CREATION_TOOL_URL = "https://www.pinterest.com/pin-creation-tool/" # Specific creation tool URL
MAX_SCHEDULED_PINS = 100 # Maximum desired scheduled pins

# Pinterest Character Limits (for reference)
PINTEREST_TITLE_LIMIT = 97  # Adjusted from 100 to allow for "..." (3 chars)
PINTEREST_DESCRIPTION_LIMIT = 797  # Pinterest's common limit is 500, user requested 800. Test carefully.

# --- GENERATE SCHEDULE TIMES FOR EVERY HOUR (24 times a day) ---
SCHEDULE_TIMES = []
for hour in range(24):
    # Create a datetime object for today with the specific hour
    temp_time = datetime.now().replace(hour=hour, minute=0, second=0, microsecond=0).time()
    SCHEDULE_TIMES.append(temp_time.strftime("%I:%M %p")) # Format as "HH:MM AM/PM"

print(f"[DEBUG] Generated SCHEDULE_TIMES: {SCHEDULE_TIMES}")

# === NEW SCROLLING CONFIGURATION ===
FIXED_SCROLL_ATTEMPTS = 5   # Number of times to scroll down the page
SCROLL_INCREMENT_PX = 1500  # Number of pixels to scroll down per attempt (adjust as needed)


# === SETUP CHROME WITH SESSION ===
running_in_ci = os.environ.get("GITHUB_ACTIONS") == "true"

options = Options()

if not running_in_ci:
    # Local run: keep user profile dir for login persistence
    profile_dir = "data"
    os.makedirs(profile_dir, exist_ok=True)
    options.add_argument(f"--user-data-dir={profile_dir}")

else:
    # Running in CI
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=4096,2160") # Set window to a very large size
    options.add_argument("--force-device-scale-factor=0.5") # Scale down content to fit more on screen
    # Further optimizations for speed and stability in headless mode
    options.add_argument("--no-sandbox") # Required for running as root in some environments (e.g., Docker)
    options.add_argument("--disable-dev-shm-usage") # Overcomes limited resource problems in Docker
    options.add_argument("--disable-notifications") # Disable browser notifications
    options.add_argument("--disable-extensions") # Disable browser extensions for slight speedup

options.add_argument("--disable-popup-blocking")
options.add_argument("--disable-infobars")
options.add_experimental_option("excludeSwitches", ["enable-logging"])

service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)

# === Load cookies in CI from cookies.json for Pinterest and Amazon affiliate ===
if running_in_ci:
    cookies_file = "cookies.json"
    if os.path.exists(cookies_file):
        with open(cookies_file, "r") as f:
            cookies_all = json.load(f)

        for site_url, cookies in cookies_all.items():
            driver.get(site_url)  # open domain before adding cookies
            for cookie in cookies:
                # Remove unsupported keys for Selenium compatibility
                cookie.pop("sameSite", None)
                cookie.pop("expiry", None)  # optional: remove expiry to avoid issues
                try:
                    driver.add_cookie(cookie)
                except Exception as e:
                    print(f"[WARN] Could not add cookie for {site_url}: {e}")
        driver.refresh()
        print("[DEBUG] Cookies loaded for Pinterest and Amazon Affiliate")
    else:
        print("[DEBUG] No cookies.json found, proceeding without cookies")
else:
    print("[DEBUG] Running locally with user-data-dir, no cookie injection")

# ---
# Helper Functions
# ---

def extract_asin(url):
    """Extracts the ASIN (10-character alphanumeric) from an Amazon product URL."""
    # Regex to find ASIN, which typically follows /dp/ or /gp/product/
    match = re.search(r'/(dp|gp/product)/([A-Z0-9]{10})', url)
    if match:
        return match.group(2)
    return None

def load_processed_asins():
    """Loads ASINs of products that have already been processed from the file."""
    if os.path.exists(PROCESSED_ASINS_FILE):
        with open(PROCESSED_ASINS_FILE, "r") as f:
            return set(f.read().splitlines())
    return set()

def save_processed_asin(asin):
    """Saves a product's ASIN to the processed file."""
    with open(PROCESSED_ASINS_FILE, "a") as f:
        f.write(asin + "\n")
        f.flush() # Ensure data is written to disk immediately
        os.fsync(f.fileno()) # Ensure OS flushes file buffers to disk
    print(f"[DEBUG] ASIN '{asin}' saved to {PROCESSED_ASINS_FILE}")

def load_uploaded_image_paths():
    """Loads absolute paths of images that have already been uploaded."""
    if os.path.exists(UPLOADED_IMAGE_PATHS_FILE):
        with open(UPLOADED_IMAGE_PATHS_FILE, "r") as f:
            return set(f.read().splitlines())
    return set()

def save_uploaded_image_path(image_path):
    """Saves the absolute path of an image to the uploaded images file."""
    with open(UPLOADED_IMAGE_PATHS_FILE, "a") as f:
        f.write(image_path + "\n")

def truncate_to_word_boundary(text, max_length):
    """
    Truncates text to max_length characters without cutting off a word.
    Appends '...' if truncated.
    """
    if len(text) <= max_length:
        return text
    truncated_text = text[:max_length]
    last_space = truncated_text.rfind(' ')
    if last_space != -1:
        return truncated_text[:last_space] + '...'
    return truncated_text + '...' # If no space found, just truncate and add ...

def load_scheduled_state():
    """
    Loads the last scheduled date and the count of pins scheduled for that day.
    Adjusts the schedule if past times on the current day have passed.
    """
    today = datetime.now().date()
    now_time = datetime.now().time()
    
    last_date = today
    last_count = 0

    if os.path.exists(SCHEDULED_TIMES_FILE):
        with open(SCHEDULED_TIMES_FILE, "r") as f:
            lines = f.readlines()
            if len(lines) == 2:
                try:
                    last_date_str = lines[0].strip()
                    last_count_str = lines[1].strip()
                    last_date = datetime.strptime(last_date_str, "%m/%d/%Y").date()
                    last_count = int(last_count_str)
                    print(f"[+] Loaded raw scheduled state: Last date {last_date}, Count {last_count}")

                    # If the loaded date is today, adjust the index to skip past times
                    if last_date == today:
                        # Find the first available time slot from the loaded index onwards
                        adjusted_index = last_count
                        for i in range(last_count, len(SCHEDULE_TIMES)):
                            scheduled_time_str = SCHEDULE_TIMES[i]
                            # Combine today's date with the scheduled time to get a full datetime object
                            scheduled_datetime_today = datetime.combine(today, datetime.strptime(scheduled_time_str, "%I:%M %p").time())
                            
                            # Compare against current full datetime
                            if scheduled_datetime_today > datetime.now():
                                adjusted_index = i
                                break
                        else: # All times for today have passed
                            print(f"[-] All schedule times for today ({today.strftime('%m/%d/%Y')}) have passed.")
                            last_date = today + timedelta(days=1)
                            adjusted_index = 0
                        last_count = adjusted_index
                        print(f"[+] Adjusted scheduled state for today: Starting from index {last_count} on {last_date.strftime('%m/%d/%Y')}.")
                    elif last_date < today:
                        # If the loaded date is in the past, reset to today and find the first future slot
                        print(f"[-] Loaded date {last_date.strftime('%m/%d/%Y')} is in the past. Resetting schedule.")
                        last_date = today
                        last_count = 0
                        # Re-evaluate for today's times
                        for i in range(len(SCHEDULE_TIMES)):
                            scheduled_time_str = SCHEDULE_TIMES[i]
                            scheduled_datetime_today = datetime.combine(today, datetime.strptime(scheduled_time_str, "%I:%M %p").time())
                            if scheduled_datetime_today > datetime.now():
                                last_count = i
                                break
                        else: # All times for today have passed
                            print(f"[-] All schedule times for today ({today.strftime('%m/%d/%Y')}) have passed. Moving to tomorrow.")
                            last_date = today + timedelta(days=1)
                            last_count = 0 # Start from the first slot tomorrow

                except ValueError:
                    print("[-] Error parsing scheduled_times.txt. Starting fresh.")
                    # Fallback to default if file content is invalid
                    last_date = today
                    last_count = 0
    else:
        print("[!] No scheduled_times.txt found. Starting fresh.")

    # Final check: if starting fresh or after a past date reset, ensure we're not scheduling for a past time today
    if last_date == today:
        current_time_system_local = datetime.now().time()
        
        # Determine the first valid index for today based on current time
        initial_index_for_today = 0
        for i, schedule_time_str in enumerate(SCHEDULE_TIMES):
            parsed_schedule_time = datetime.strptime(schedule_time_str, "%I:%M %p").time()
            if parsed_schedule_time > current_time_system_local:
                initial_index_for_today = i
                break
        else: # All times for today have passed
            initial_index_for_today = len(SCHEDULE_TIMES) # Indicate no more slots today

        # If the loaded/default index points to a time that has already passed, advance to the next valid slot or next day
        if last_count < initial_index_for_today:
            print(f"[-] Loaded schedule index ({last_count}) points to a time that has already passed today. Adjusting.")
            last_count = initial_index_for_today
            if last_count >= len(SCHEDULE_TIMES): # If we've exhausted today's times
                last_date += timedelta(days=1)
                last_count = 0
                print(f"[!] All schedule times for today ({today.strftime('%m/%d/%Y')}) have passed. Starting scheduling from tomorrow: {last_date.strftime('%m/%d/%Y')}")

    print(f"[+] Final adjusted scheduled state: Date {last_date}, Count {last_count}")
    return last_date, last_count

def save_scheduled_state(date_obj, scheduled_count_today):
    """Saves the current scheduled date and count to the file."""
    with open(SCHEDULED_TIMES_FILE, "w") as f:
        f.write(date_obj.strftime("%m/%d/%Y") + "\n")
        f.write(str(scheduled_count_today) + "\n")
    print(f"[+] Saved scheduled state: Date {date_obj.strftime('%m/%d/%Y')}, Count {scheduled_count_today}")


# ---
# Initialization
# ---

os.makedirs(DOWNLOAD_DIR, exist_ok=True)
processed_asins = load_processed_asins()
uploaded_image_paths = load_uploaded_image_paths()  # Load previously uploaded image paths

print(f"[!] Loaded {len(processed_asins)} previously processed ASINs from {PROCESSED_ASINS_FILE}.")
# Display only the first 5 processed ASINs to avoid huge log output if many exist
print(f"[DEBUG] Current processed_asins set: {list(processed_asins)[:5]}... (first 5 if any)")
print(f"[!] Loaded {len(uploaded_image_paths)} previously uploaded image paths from {UPLOADED_IMAGE_PATHS_FILE}.")

# Load initial scheduling state
current_schedule_date, current_schedule_index = load_scheduled_state()


# ---
# Pinterest Login and Scheduled Pins Check
# ---

print("[+] Navigating to Pinterest...")
driver.get(PINTEREST_URL)

try:
    # Wait for the profile icon to be present (indicates successful login or loaded page)
    # The provided XPath is for an <a> tag. Let's try to be more robust.
    profile_icon_selector = 'a[aria-label="Your profile"] div[data-test-id="gestalt-avatar-svg"]'
    WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.CSS_SELECTOR, profile_icon_selector)))
    print("[+] Pinterest page loaded. Assuming user is logged in or can log in manually.")

    # 2. Click on 'Your Profile' icon
    print("[+] Clicking on 'Your Profile' icon...")
    profile_icon = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, 'a[aria-label="Your profile"]'))
    )
    profile_icon.click()
    print("[+] Navigated to profile page.")
    time.sleep(3) # Give time for the profile page to load content

    # 3. Take a look at the scheduled pins count
    scheduled_pins_count = 0
    try:
        # Locate the div containing "Scheduled Pins" and then its sibling with the count
        scheduled_pins_container = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//div[contains(@class, "X8m") and text()="Scheduled Pins"]/following-sibling::div[contains(@class, "zI7") and contains(@class, "zX-")]'))
        )
        # Within this container, find the div that holds the "73 Pins" text
        count_text_element = scheduled_pins_container.find_element(By.XPATH, './/div[contains(@class, "JlN") and contains(@class, "p3S")]')
        
        count_match = re.search(r'(\d+)\s*Pins', count_text_element.text)
        if count_match:
            scheduled_pins_count = int(count_match.group(1))
            print(f"[+] Found {scheduled_pins_count} scheduled pins.")
        else:
            print("[-] Could not extract scheduled pins count from text.")
    except Exception as e:
        print(f"[-] Could not find scheduled pins count element or extract count: {e}. Assuming 0.")

    # Calculate how many pins we need to schedule
    pins_to_schedule_needed = MAX_SCHEDULED_PINS - scheduled_pins_count
    if pins_to_schedule_needed <= 0:
        print(f"[✓] Already reached or exceeded {MAX_SCHEDULED_PINS} scheduled pins ({scheduled_pins_count} found). Exiting script.")
        driver.quit()
        exit()
    else:
        print(f"[+] Need to schedule {pins_to_schedule_needed} more pins to reach {MAX_SCHEDULED_PINS}.")
        NUM_PRODUCTS = pins_to_schedule_needed # Set the limit for product processing

except Exception as e:
    print(f"[!] Error during Pinterest initial setup or scheduled pins check: {e}")
    print("[!] Continuing with script, but Pinterest interaction might be problematic.")
    # If we couldn't get scheduled pins count, proceed with NUM_PRODUCTS as None (or a default large number)
    if NUM_PRODUCTS is None:
        NUM_PRODUCTS = 100 # Fallback to scheduling a reasonable number if count fails

# ---
# Scrape Amazon Deals
# ---

print("[+] Opening Amazon Deals Page...")
# Modifying the URL to specifically target the 'Women Clothing' department
# The department ID for 'Women Clothing' is 7141124011/7147440011.
driver.get("https://www.amazon.com/gp/goldbox?ref_=nav_cs_gb&discounts-widget=%2522%257B%255C%2522state%255C%2522%253A%257B%255C%2522refinementFilters%255C%2522%253A%257B%255C%2522departments%255C%2522%253A%255B%255C%25227141124011/7147440011%255C%2522%255D%257D%257D%252C%255C%2522version%255C%2522%253A1%257D%2522&bubble-id=trending-bubble")
try:
    # Wait for product cards to load, indicating page is ready
    WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'a[data-testid="product-card-link"]')))
except Exception as e:
    print(f"[!] Could not load Amazon Deals page or find product cards: {e}")
    driver.quit()
    exit()

print("[+] Collecting product links with fixed scrolling...")
product_links_to_process = []
unique_asins_found_this_run = set()  # To track ASINs encountered in the current scrape session

# --- MODIFIED SCROLLING LOGIC ---
for scroll_attempt in range(FIXED_SCROLL_ATTEMPTS):
    print(f"[*] Scrolling attempt {scroll_attempt + 1}/{FIXED_SCROLL_ATTEMPTS}...")
    driver.execute_script(f"window.scrollBy(0, {SCROLL_INCREMENT_PX});")
    time.sleep(2) # Give some time for new content to load

    # Re-collect all product cards after scroll
    current_product_cards = driver.find_elements(By.CSS_SELECTOR, 'a[data-testid="product-card-link"]')
    newly_found_count = 0
    for card in current_product_cards:
        full_href = card.get_attribute("href")
        if full_href:
            asin = extract_asin(full_href)
            if asin:
                if asin not in processed_asins and asin not in unique_asins_found_this_run:
                    product_links_to_process.append(full_href)  # Store the full URL for navigation
                    unique_asins_found_this_run.add(asin)  # Add ASIN to the set for current run
                    newly_found_count += 1
    
    print(f"[+] Found {newly_found_count} new unique products after scroll. Total collected: {len(product_links_to_process)}")

print(f"[+] Finished fixed scrolling. Final count: {len(product_links_to_process)} new products to process.")
if NUM_PRODUCTS:
    product_links_to_process = product_links_to_process[:NUM_PRODUCTS]

# ---
# Process Each Product and Upload to Pinterest
# ---

pins_scheduled_this_run = 0

for i, link in enumerate(product_links_to_process):
    if pins_scheduled_this_run >= NUM_PRODUCTS: # Stop if we've scheduled enough
        print(f"[!] Reached target of {NUM_PRODUCTS} pins to schedule. Stopping product processing.")
        break

    current_product_asin = extract_asin(link)
    if not current_product_asin:
        print(f"[!] Skipping product {i+1}, ASIN not found in link: {link}.")
        continue

    # Initialize folder variable for cleanup in case of early errors
    folder = None
    product_category = None # Initialize product_category for each product
    normalized_category = "Women's Clothing" # Target category for filtering

    try:
        print(f"\n[*] Processing product {i+1}/{len(product_links_to_process)} (ASIN: {current_product_asin}): {link}")

        # Navigate to product page
        driver.get(link)
        WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.ID, "productTitle")))

        # Generate a unique folder name using the ASIN
        folder = os.path.join(DOWNLOAD_DIR, current_product_asin)
        os.makedirs(folder, exist_ok=True)


        # === GET CATEGORY FROM BREADCRUMBS ===
        print(f"[+] Attempting to get category from breadcrumbs for ASIN {current_product_asin}...")
        full_breadcrumbs = None
        try:
            # Find the breadcrumb container
            breadcrumbs_ul = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "#wayfinding-breadcrumbs_feature_div ul.a-horizontal"))
            )
            # Extract all breadcrumb links to get the full category path
            breadcrumb_links = breadcrumbs_ul.find_elements(By.CSS_SELECTOR, "li a")
            
            if breadcrumb_links:
                # Get all category names from breadcrumbs
                breadcrumb_categories = [link.text.strip() for link in breadcrumb_links if link.text.strip()]
                full_breadcrumbs = " > ".join(breadcrumb_categories)
                print(f"[+] Extracted full breadcrumbs: {full_breadcrumbs}")
        except Exception as e:
            print(f"[-] Could not extract breadcrumbs: {e}")
            full_breadcrumbs = None # Ensure it is None on failure

        # === IMPORTANT: FILTER PRODUCT BASED ON BREADCRUMBS ===
        # Check if both 'Women' and 'Clothing' appear in the breadcrumbs
        if not full_breadcrumbs or 'Women' not in full_breadcrumbs or 'Clothing' not in full_breadcrumbs:
            print(f"[-] Breadcrumbs '{full_breadcrumbs}' do not contain both 'Women' and 'Clothing'. Skipping product.")
            # We must save the ASIN as processed here to avoid retrying this product on a future run.
            save_processed_asin(current_product_asin)
            if os.path.exists(folder):
                shutil.rmtree(folder)
                print(f"[-] Cleaned up product folder: {folder}")
            continue # Skip to the next product in the loop

        # === Mark ASIN as processed ONLY after category validation passes ===
        # This ensures that we only save valid products as processed, allowing retries for products with incorrect categories.
        save_processed_asin(current_product_asin)
        print(f"[✓] ASIN {current_product_asin} is now marked as processed (category validation passed).")


        # === GET PRODUCT TITLE ===
        raw_title = f"Product_{current_product_asin}"  # Default fallback
        try:
            title_element = WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.ID, "productTitle")))
            raw_title = title_element.text.strip()
        except Exception as e:
            print(f"[!] Could not get product title for ASIN {current_product_asin}: {e}")
        # Apply truncation with word boundary
        title = truncate_to_word_boundary(raw_title, PINTEREST_TITLE_LIMIT)


        # === GET DESCRIPTION ===
        desc_parts = []
        # Attempt to extract "Product details" (key-value pairs)
        try:
            product_details_div = WebDriverWait(driver, 1).until(
                EC.presence_of_element_located((By.XPATH, "//h3[@class='product-facts-title' and contains(text(), 'Product details')]/following-sibling::div[contains(@class, 'a-section') and @role='list']"))
            )
            detail_rows = product_details_div.find_elements(By.CSS_SELECTOR, ".product-facts-detail")
            if detail_rows:
                for row in detail_rows:
                    key_span = row.find_element(By.CSS_SELECTOR, ".a-col-left span.a-color-base")
                    value_span = row.find_element(By.CSS_SELECTOR, ".a-col-right span.a-color-base")
                    if key_span and value_span:
                        desc_parts.append(f"{key_span.text.strip()}: {value_span.text.strip()}")
                if desc_parts:
                    print("[+] Extracted 'Product details' section.")
            else:
                print("[-] No detailed 'Product details' found or structure changed.")

        except Exception as e:
            print(f"[-] Could not get 'Product details' section for ASIN {current_product_asin}")

        # Attempt to extract traditional #productDescription
        try:
            product_description_div = WebDriverWait(driver, 1).until(
                EC.presence_of_element_located((By.ID, "productDescription"))
            )
            if product_description_div.text.strip():
                desc_parts.append(product_description_div.text.strip())
                print("[+] Extracted 'productDescription' section.")
        except:
            pass # No productDescription element found or accessible

        # Attempt to get general feature bullets, explicitly excluding "About this item" section
        try:
            feature_bullets_ul = WebDriverWait(driver, 1).until(
                EC.presence_of_element_located((By.ID, "feature-bullets"))
            )
            # Check if this section explicitly contains the "About this item" heading
            about_this_item_heading_found = False
            try:
                feature_bullets_ul.find_element(By.XPATH, ".//h3[contains(text(), 'About this item')]")
                about_this_item_heading_found = True
            except:
                pass # No "About this item" heading found within this feature_bullets_ul

            if not about_this_item_heading_found:
                list_items = feature_bullets_ul.find_elements(By.TAG_NAME, "li")
                if list_items:
                    for li in list_items:
                        item_text = li.text.strip()
                        if item_text:  # Ensure the list item is not empty
                            desc_parts.append(item_text)
                    print("[+] Extracted general 'feature-bullets' (not 'About this item').")
            else:
                print("[-] Skipping 'feature-bullets' as it appears to be 'About this item' section.")

        except Exception as e:
            print(f"[-] Could not get 'feature-bullets' for ASIN {current_product_asin}")

        # If no parts were found, set a default description
        if not desc_parts:
            raw_desc = "No description found."
            print("[!] No detailed description found. Using fallback.")
        else:
            # Join all collected parts with newlines
            raw_desc = "\n".join(desc_parts)

        # Apply final truncation with ellipsis for description
        desc = truncate_to_word_boundary(raw_desc, PINTEREST_DESCRIPTION_LIMIT)


        # === GET SHORTLINK (AFFILIATE LINK) ===
        short_link = link  # Default to original link if affiliate link extraction fails
        print(f"[+] Attempting to get Amazon affiliate short link for ASIN {current_product_asin}...")

        try:
            # Scroll to the bottom to ensure the "Share" or "Get Link" section is visible
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(0.5) # Reduced sleep after scroll

            # Wait for the 'Share' button/icon to become visible and clickable.
            share_button_selectors = [
                (By.ID, "amzn-ss-get-link-button"),  # Common for Amazon Associates toolbar
                (By.CSS_SELECTOR, 'a[data-csa-c-slot-id="btf-desktop-share-link"]'), # Newer share button style
                (By.XPATH, "//a[contains(@href, '/share/product/')]"), # Generic share link
                (By.XPATH, "//div[@id='social-share-cn']//a[contains(text(), 'Share')]"), # Share div
                (By.XPATH, "//span[contains(@class, 'a-button') and .//span[contains(text(), 'Share')]]"), # Share button as span
                (By.XPATH, "//a[contains(text(), 'Share')]") # Broadest share link selector
            ]

            share_button = None
            for selector_type, selector_value in share_button_selectors:
                try:
                    share_button = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((selector_type, selector_value))
                    )
                    print(f"[+] Found potential share button using {selector_type}: {selector_value}")
                    break
                except:
                    pass

            if share_button:
                # Use ActionChains for more reliable clicking, especially if element is partially obscured
                ActionChains(driver).move_to_element(share_button).click().perform()
                print("[+] Clicked the 'Share' or 'Get Link' button.")
                
                # Wait for the popover's content to be ready
                WebDriverWait(driver, 10).until(
                    EC.visibility_of_element_located((By.CSS_SELECTOR, ".a-popover-wrapper #amzn-ss-popover-text-preload-content-container"))
                )
                print("[+] Share pop-up content is visible.")

                # Check for "Unable to generate link" or "Excluded Products" messages
                try:
                    failure_message = driver.find_element(By.CLASS_NAME, "amzn-ss-popover-link-failure-message")
                    if "block" in failure_message.get_attribute("style"): # Check if it's visible
                        print("[-] Link generation failed (pop-up message). Falling back to original product URL.")
                        raise Exception("Link generation failed") # Raise an exception to jump to fallback
                except:
                    pass # Message not present or not visible, continue

                try:
                    third_party_message = driver.find_element(By.CLASS_NAME, "amzn-ss-popover-third-party-message")
                    if "block" in third_party_message.get_attribute("style"): # Check if it's visible
                        print("[-] Product is excluded from Associates Program (pop-up message). Falling back to original product URL.")
                        raise Exception("Product excluded") # Raise an exception to jump to fallback
                except:
                    pass # Message not present or not visible, continue

                # Wait for the short link textarea to appear and have a value
                short_link_textarea = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "amzn-ss-text-shortlink-textarea"))
                )
                
                WebDriverWait(driver, 5).until(
                    lambda driver: short_link_textarea.get_attribute("value").strip() != "" # Wait for any non-empty value
                )

                extracted_short_link = short_link_textarea.get_attribute("value")
                
                # IMPORTANT: Check if the extracted short link is actually populated and looks like a URL
                if extracted_short_link and extracted_short_link.strip().startswith("http"):
                    short_link = extracted_short_link.strip()
                    print(f"[+] Extracted short link: {short_link}")
                else:
                    print("[-] Extracted short link was empty or invalid after pop-up appeared. Falling back to original product URL.")


                # Try to close the pop-up/overlay gracefully
                try:
                    close_button = WebDriverWait(driver, 1).until(
                        EC.element_to_be_clickable((By.ID, "amzn-ss-box-close"))
                    )
                    close_button.click()
                    print("[+] Closed the short link pop-up.")
                except:
                    print("[-] Could not find or click pop-up close button. Attempting ESC key.")
                    ActionChains(driver).send_keys(Keys.ESCAPE).perform()
            else:
                print("[!] No 'Share' or 'Get Link' button found after trying multiple selectors. Using original link.")

        except Exception as e:
            print(f"[!] Error getting shortlink or category for ASIN {current_product_asin}, using original link: {e}")
            # Ensure the pop-up is closed if an error occurred during its handling
            try:
                # Check for the popover wrapper and try to close it if visible
                popover_wrapper = driver.find_element(By.CLASS_NAME, "a-popover-wrapper")
                if popover_wrapper.is_displayed():
                    print("[-] Attempting to close pop-up due to error during link extraction.")
                    ActionChains(driver).send_keys(Keys.ESCAPE).perform()
                    time.sleep(0.5) # Give it a moment to close
            except:
                pass # Pop-up not found or already closed


        # === GET AND DOWNLOAD MAIN IMAGE ONLY ===
        print(f"[+] Attempting to fetch and download main image for ASIN {current_product_asin}...")
        downloaded_images = [] # This list will hold only the main image path if successful

        main_src = None
        try:
            # Look for the main image element using common IDs
            main_image_element = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "#landingImage, #imgTagWrapperId img, img#imageBlock_feature_div img"))
            )
            main_src = main_image_element.get_attribute("src")
            
            if main_src:
                # Clean up Amazon's image URLs to get a higher resolution version
                # This often removes size modifiers like ._AC_SX466_.jpg
                main_src_cleaned = main_src.split("._")[0].split(".SS40_")[0].split(".AC_US40_")[0] + ".jpg"
                print(f"[+] Found main image URL: {main_src_cleaned}")

                # Directly attempt to download and save this main image
                try:
                    img_data = requests.get(main_src_cleaned, timeout=10).content
                    img = Image.open(BytesIO(img_data))
                    if img.width >= MIN_WIDTH and img.height >= MIN_HEIGHT:
                        # Save the main image with a fixed name
                        img_path = os.path.join(folder, f"main_img.jpg")
                        img.save(img_path)
                        downloaded_images.append(img_path)
                        print(f"[+] Saved main image: {img_path}")
                    else:
                        print(f"[-] Main image {main_src_cleaned} too small ({img.width}x{img.height}). Skipping.")
                except Exception as e:
                    print(f"[!] Error downloading main image {main_src_cleaned} for ASIN {current_product_asin}: {e}")
            else:
                print(f"[-] No 'src' attribute found for the identified main image element on ASIN {current_product_asin}.")
        except Exception as e:
            print(f"[!] Could not find the main image element for ASIN {current_product_asin}: {e}")

        # Check if the main image was successfully downloaded. If not, clean up and move on.
        if not downloaded_images:
            print(f"[!] Skipping product ASIN {current_product_asin}, no valid main image downloaded. Moving to next product.")
            # ASIN was already marked processed earlier.
            if os.path.exists(folder): shutil.rmtree(folder) # Clean up empty/failed folder
            continue

        # --- PROCESS ONLY THE FIRST (MAIN) DOWNLOADED IMAGE FOR PINTEREST ---
        image_to_upload_path = os.path.abspath(downloaded_images[0]) # Get the absolute path of the single main image

        if image_to_upload_path in uploaded_image_paths:
            print(f"[-] SKIPPING (Image Already Uploaded): Product ASIN: {current_product_asin}, main image '{os.path.basename(image_to_upload_path)}' was already uploaded.")
            # ASIN was already marked processed earlier.
            if os.path.exists(folder):
                shutil.rmtree(folder) # Clean up all images for this product, as we only need one
                print(f"[-] Cleaned up product folder: {folder}")
            continue # Move to the next product

        try:
            print(f"\n[->] Uploading ONLY the main image for ASIN: {current_product_asin} ({os.path.basename(image_to_upload_path)})")

            # === OPEN PINTEREST CREATOR ===
            driver.get(PINTEREST_CREATION_TOOL_URL)

            # Wait for the upload input to be present (might need to click "Create Pin" first)
            try:
                # Look for the Create Pin button, prioritizing one with text or role button
                create_pin_button = WebDriverWait(driver, 1).until(
                    EC.element_to_be_clickable((By.XPATH, "//div[text()='Create Pin'] | //button[contains(.,'Create Pin')] | //div[@data-test-id='desktop-create-button']"))
                )
                create_pin_button.click()
                print("[+] Clicked 'Create Pin' button on Pinterest.")
            except:
                print("[-] 'Create Pin' button not found or already on creation page, proceeding.")
                pass

            img_input = WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.ID, "storyboard-upload-input"))
            )

            # === UPLOAD IMAGE ===
            print(f"[+] Uploading image to Pinterest: {image_to_upload_path}")
            img_input.send_keys(image_to_upload_path)

            # Wait for the title field (or another key element) to become available after image upload
            WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.ID, "storyboard-selector-title"))
            )
            time.sleep(0.5) # Reduced buffer for rendering after image upload

            # === FILL TITLE ===
            title_input = driver.find_element(By.ID, "storyboard-selector-title")
            title_input.clear()
            title_input.send_keys(title) # 'title' is already truncated

            # === FILL DESCRIPTION ===
            desc_box = driver.find_element(By.CLASS_NAME, "public-DraftEditor-content")
            # Using ActionChains to click and send keys is often more robust for complex text areas
            ActionChains(driver).move_to_element(desc_box).click().send_keys(desc).perform() # 'desc' is already truncated

            # === FILL LINK ===
            link_input = driver.find_element(By.ID, "WebsiteField")
            link_input.clear()
            link_input.send_keys(short_link)

            # ---
            # === SELECT PINTEREST BOARD BASED ON CATEGORY ===
            # ---
            if product_category: # Only attempt if a category was found
                print(f"[+] Attempting to select Pinterest board: '{normalized_category}'...")
                board_selected = False
                try:
                    # 1. Click the board dropdown button
                    board_dropdown_button = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, '[data-test-id="board-dropdown-select-button"]'))
                    )
                    board_dropdown_button.click()
                    print("[+] Clicked board dropdown button.")

                    # 2. Try to find and select an existing board
                    board_selector = f'div[data-test-id^="board-row-"] div[title="{normalized_category}"]'
                    try:
                        category_board_element_title_div = WebDriverWait(driver, 5).until( # Shorter wait for existing
                            EC.element_to_be_clickable((By.CSS_SELECTOR, board_selector))
                        )
                        clickable_board_row = category_board_element_title_div.find_element(By.XPATH, './ancestor::div[@role="button"]')
                        
                        if clickable_board_row:
                            ActionChains(driver).move_to_element(clickable_board_row).click().perform()
                            print(f"[+] Selected existing board: '{normalized_category}'")
                            board_selected = True
                        else:
                            print(f"[!] Could not find clickable element for existing board '{normalized_category}' despite finding title div. Skipping board selection.")
                    except TimeoutException:
                        print(f"[-] Board '{normalized_category}' not found in existing boards.")

                    if not board_selected:
                        print(f"[+] Attempting to create new board: '{normalized_category}'...")
                        # Click the 'Create board' button
                        create_board_button = WebDriverWait(driver, 5).until(
                            EC.element_to_be_clickable((By.CSS_SELECTOR, 'div[data-test-id="create-board"] [data-test-id="create-board-button"]'))
                        )
                        create_board_button.click()
                        print("[+] Clicked 'Create board' button.")

                        # Wait for the board name input field to appear
                        board_name_input = WebDriverWait(driver, 5).until(
                            EC.presence_of_element_located((By.ID, "boardEditName"))
                        )
                        board_name_input.clear()
                        board_name_input.send_keys(normalized_category)
                        print(f"[+] Entered new board name: '{normalized_category}'")

                        # Click the 'Create' button to finalize board creation
                        create_submit_button = WebDriverWait(driver, 5).until(
                            EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[data-test-id="board-form-submit-button"]'))
                        )
                        create_submit_button.click()
                        print(f"[+] Clicked 'Create' to finalize new board '{normalized_category}'.")
                        
                        # Pinterest should automatically select the new board after creation, just wait for stability
                        time.sleep(2) # Give it a moment to register selection and close modal
                        board_selected = True
                        print(f"[✓] New board '{normalized_category}' created and selected.")

                except Exception as e:
                    print(f"[!] Failed to select or create board '{normalized_category}': {e}")
                    # Try to close the dropdown if it's open, by pressing ESC
                    ActionChains(driver).send_keys(Keys.ESCAPE).perform()
            else:
                print("[-] No product category found or extracted as unavailable, skipping board selection/creation.")
            
            # ---
            # === SCHEDULE PIN FOR LATER PUBLICATION ===
            # ---
            if product_category: # Only schedule if a category was successfully handled
                print("[+] Attempting to schedule pin for later publication...")
                try:
                    # 1. Click the "Publish at a later date" checkbox/switch
                    schedule_switch_label = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, 'label[for="pin-draft-switch-group"]'))
                    )
                    schedule_switch_label.click()
                    print("[+] Clicked 'Publish at a later date' switch.")

                    # Calculate the next date and time to schedule
                    schedule_date_to_use = current_schedule_date.strftime("%m/%d/%Y")
                    
                    # Ensure current_schedule_index is within bounds (should be handled by load_scheduled_state but good to double-check)
                    if current_schedule_index >= len(SCHEDULE_TIMES):
                        print(f"[-] WARNING: current_schedule_index ({current_schedule_index}) out of bounds for SCHEDULE_TIMES. Resetting to 0.")
                        current_schedule_index = 0
                        current_schedule_date += timedelta(days=1)
                        schedule_date_to_use = current_schedule_date.strftime("%m/%d/%Y") # Update date if we rolled over
                        save_scheduled_state(current_schedule_date, current_schedule_index) # Save the new state

                    schedule_time_to_use = SCHEDULE_TIMES[current_schedule_index]

                    print(f"[+] Scheduling pin for: {schedule_date_to_use} at {schedule_time_to_use}")

                    # 2. Fill the date input field
                    date_input = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, '[data-test-id="pin-draft-schedule-date-field-container"] input[placeholder="MM/DD/YYYY"]'))
                    )
                    date_input.send_keys(Keys.CONTROL + "a") # Select all
                    date_input.send_keys(Keys.DELETE) # Delete selected
                    date_input.send_keys(schedule_date_to_use)
                    date_input.send_keys(Keys.TAB) 
                    time.sleep(0.5)

                    # 3. Click the time input to open the dropdown
                    time_input_field = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, '[data-test-id="pin-draft-schedule-time-field-container"] input[placeholder="Time"]'))
                    )
                    time_input_field.click()
                    print(f"[+] Clicked time input field to open dropdown for {schedule_time_to_use}.")
                    time.sleep(1) # Give it a moment for the dropdown to render

                    # 4. Select the correct time from the dropdown, with scrolling
                    # The XPath should now correctly target only visible options
                    time_option_xpath = f'//button[@data-test-id="time-field-option"]//div[@class="X8m zDA IZT eSP dyH LTB bB3 mvk" and text()="{schedule_time_to_use}"]'
                    
                    # Find the scrollable container for the time options
                    scrollable_time_container = WebDriverWait(driver, 5).until(
                        EC.presence_of_element_located((By.XPATH, '//div[contains(@class, "BTb") and contains(@style, "max-height")]'))
                    )
                    print(f"[+] Found scrollable time container: {scrollable_time_container.get_attribute('outerHTML')[:100]}...")


                    found_and_clicked_time = False
                    scroll_attempts = 0
                    max_scroll_attempts = 10 # Prevent infinite loops

                    while not found_and_clicked_time and scroll_attempts < max_scroll_attempts:
                        try:
                            # Try to find the element
                            selected_time_element = WebDriverWait(driver, 2).until(
                                EC.element_to_be_clickable((By.XPATH, time_option_xpath))
                            )
                            # If found and clickable, click it
                            driver.execute_script("arguments[0].click();", selected_time_element)
                            print(f"[+] Selected time '{schedule_time_to_use}' from dropdown after {scroll_attempts} scroll attempts.")
                            found_and_clicked_time = True
                            time.sleep(1) # Give it a moment to register selection and close dropdown
                        except TimeoutException:
                            print(f"[-] Time option '{schedule_time_to_use}' not immediately visible. Scrolling dropdown... (attempt {scroll_attempts + 1})")
                            # If not found, scroll the container
                            driver.execute_script("arguments[0].scrollTop += 50;", scrollable_time_container) # Scroll down by 50px
                            scroll_attempts += 1
                            time.sleep(0.5) # Small pause after scroll

                    if not found_and_clicked_time:
                        raise Exception(f"Could not find or click time option '{schedule_time_to_use}' after {max_scroll_attempts} scroll attempts.")


                    # 5. Click the FIRST 'Schedule' button (to open confirmation modal)
                    first_schedule_button = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.XPATH, "//button/div/div[text()='Schedule']"))
                    )
                    first_schedule_button.click()
                    print(f"[✓] Initial 'Schedule' button clicked for ASIN {current_product_asin}.")
                    time.sleep(1) # Give a moment for the confirmation overlay to appear

                    # --- Click the CONFIRMATION 'Schedule' button ---
                    confirmation_schedule_button = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, '[data-test-id="schedule-pin-confirm-button"] button'))
                    )
                    driver.execute_script("arguments[0].click();", confirmation_schedule_button)
                    print(f"[✓] Confirmation 'Schedule' button clicked via JavaScript for ASIN {current_product_asin}.")
                    time.sleep(1) # Give a moment for the confirmation message to appear

                    # === NEW CONFIRMATION STEP: WAIT FOR THE SCHEDULED MESSAGE ===
                    # Construct the expected date string (e.g., "Aug 10")
                    expected_date_str_format = "%b %d"
                    expected_date_for_msg = current_schedule_date.strftime(expected_date_str_format)

                    # Full expected message substring
                    expected_confirmation_text = f"Scheduled for {expected_date_for_msg} at {schedule_time_to_use}"
                    print(f"[+] Waiting for confirmation message: '{expected_confirmation_text}'...")

                    # Use a more general XPath that looks for a span containing the "Scheduled for" text
                    # and then verifies the full text content. This is more resilient to class changes.
                    confirmation_span_xpath = '//span[contains(text(), "Scheduled for")]'

                    try:
                        confirmation_element = WebDriverWait(driver, 20).until(
                            EC.visibility_of_element_located((By.XPATH, confirmation_span_xpath))
                        )
                        
                        # After locating the element, verify its full text content
                        if confirmation_element.text == expected_confirmation_text:
                            print(f"[✓] CONFIRMED: Pinterest displayed the exact message: '{expected_confirmation_text}'.")
                        else:
                            # Log a warning if the text doesn't match exactly, even if "Scheduled for" was found.
                            print(f"[-] WARNING: Found an element containing 'Scheduled for', but the text did not match the full expected message.")
                            print(f"    Expected: '{expected_confirmation_text}'")
                            print(f"    Found:    '{confirmation_element.text}'")
                        
                        # Optionally, wait for it to disappear, or just proceed knowing it was there
                        # WebDriverWait(driver, 5).until(
                        #     EC.invisibility_of_element_located((By.XPATH, confirmation_span_xpath))
                        # )
                        # print("[+] Confirmation message disappeared.")
                        
                    except TimeoutException:
                        print(f"[-] WARNING: Did not find any confirmation message containing 'Scheduled for'. Proceeding but may indicate an issue.")
                    # === END NEW CONFIRMATION STEP ===

                    # Update scheduling state for the next pin
                    current_schedule_index += 1
                    if current_schedule_index >= len(SCHEDULE_TIMES):
                        current_schedule_index = 0
                        current_schedule_date += timedelta(days=1)
                        print(f"[!] All slots for {current_schedule_date - timedelta(days=1)} used. Moving to next day: {current_schedule_date.strftime('%m/%d/%Y')}")
                    
                    save_scheduled_state(current_schedule_date, current_schedule_index)
                    pins_scheduled_this_run += 1 # Increment count of successfully scheduled pins

                    # Wait for successful upload/scheduling confirmation to disappear, which is the main overlay
                    try:
                        WebDriverWait(driver, 15).until(
                            EC.invisibility_of_element_located((By.XPATH, "//div[@data-test-id='pin-creation-overlay']"))
                        )
                        print("[+] Pin creation overlay disappeared, indicating full process completion.")
                    except TimeoutException:
                        print("[-] Pin creation overlay did not disappear after scheduling. May still be processing or an issue occurred.")

                except Exception as e:
                    print(f"[!] FAILED TO SCHEDULE PIN for ASIN {current_product_asin}: {e}")
                    ActionChains(driver).send_keys(Keys.ESCAPE).perform() # Try to close modal on error
            else:
                print("[-] No product category, skipping scheduling.")

            print(f"[✓] Successfully processed pin for {title} (ASIN: {current_product_asin})")
            save_uploaded_image_path(image_to_upload_path)
            
            if os.path.exists(folder):
                shutil.rmtree(folder)
                print(f"[-] Cleaned up product folder: {folder}")

        except Exception as e:
            print(f"[!] FAILED TO PREPARE OR SCHEDULE PIN for ASIN {current_product_asin} with image {os.path.basename(image_to_upload_path)}: {e}")
            if os.path.exists(folder):
                shutil.rmtree(folder)
                print(f"[-] Cleaned up failed product folder: {folder}")
            continue

    except Exception as e:
        print(f"[!] FAILED TO PROCESS ENTIRE PRODUCT (ASIN: {current_product_asin}, Link: {link}): {e}")
        if folder and os.path.exists(folder):
            shutil.rmtree(folder)
            print(f"[-] Cleaned up partial download folder: {folder}")

# ---
# Final Cleanup
# ---

print("\n[✓] Finished processing.")
print(f"[DEBUG] Final processed_asins set before quit: {list(processed_asins)[:5]}... (first 5 if any)")
driver.quit()
print("[!] Script execution complete. Check your 'selenium' profile for Pinterest status.")
